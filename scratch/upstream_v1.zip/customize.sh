mods_center() {
    ui_print "
     __  ___        __     _____         __         
    /  |/  /__  ___/ /__  / ___/__ ___  / /____ ____
   / /|_/ / _ \/ _  (_-< / /__/ -_) _ \/ __/ -_) __/
  /_/  /_/\___/\_,_/___/ \___/\__/_//_/\__/\__/_/ "
}

support_verification() {
	Android=$(getprop ro.build.version.release)
	HOS=$(getprop ro.mi.os.version.name)
	HOSwp=$(getprop ro.miui.ui.version.name)

	if [ "$Android" -lt 13 ]; then
		echo "- Android version is not supported."
		exit 1
	elif [[ ! "$HOS" == *OS* || ! "$HOSwp" == *V8* ]]; then
		echo "- This module only supports HyperOS."
		exit 1
	fi
	
	if [ "$Android" -ge 13 ]; then
    ui_print "
    ------------------------------------------
                     READ!!!                  
     Signature verification must be disabled  
       otherwise, the module will not work    
    ------------------------------------------
    "
	fi
}

install_files() {
    app_package="com.miui.aod"
    app_mod_name="MIUIAod"
    
    ui_print "- Checking for installed $app_package updates"
    $(pm uninstall-system-updates "$app_package")
    
    app_path=$(pm path "$app_package" | sed 's/package://')
    app_name=$(basename "$app_path" | sed 's/.apk//')
        
    if [[ $app_path == *product* ]]; then
        partition=/system/product
    elif [[ $app_path == *system* ]]; then
        partition=/system
    else
        ui_print "  Error, can't find $app_package"
        exit 1
    fi
    
    ui_print "- Replacing $app_package"
    mv "$MODPATH/files/$app_mod_name.apk" "$MODPATH/files/$app_name.apk"
    mkdir -p "$MODPATH$partition/priv-app/$app_name"
    cp -f "$MODPATH/files/$app_name.apk" "$MODPATH$partition/priv-app/$app_name"
    
    CPU_ABI=$(getprop ro.product.cpu.abi)
    
    case "$CPU_ABI" in
        arm64*) Type=arm64 Libs=arm64-v8a;;
        arm*) Type=arm Libs=armeabi-v7a;;
        x86_64*) Type=x86_64 Libs=x86_64;;
        x86*) Type=x86 Libs=x86;;
    esac

    ui_print "- Patching libs"
    mkdir -p "$MODPATH$partition/priv-app/$app_name/lib/$Type"
    unzip -o "$MODPATH/files/$app_name.apk" -d "$MODPATH/$app_name" >&2
    cp -rf "$MODPATH/$app_name/lib/$Libs/"* "$MODPATH$partition/priv-app/$app_name/lib/$Type"
    rm -rf "$MODPATH/$app_name"
		
	device=$(getprop ro.boot.product.hardware.sku)
	features_path="$MODPATH/system/product/etc/device_features"
	device_features="/system/product/etc/device_features/$device.xml"
	mkdir -p $features_path
	cp -f $device_features $features_path

    if [ -z $(getprop ro.vendor.display.type) ]; then
        if [ -f "$MODPATH$device_features" ]; then
            ui_print "- IPS Screen detected, trying to add AOD support..."
            if ! sed -i '/<\/features>/ i\
    <bool name="support_aod">true</bool>\
    <bool name="support_aod_notification_animate">true</bool>\
    <bool name="aod_support_keycode_goto_dismiss">true</bool>\
    <bool name="support_screen_color_persist">true</bool>\
    <bool name="doze_display_state_supported">true</bool>\
    <bool name="doze_proximity_check_before_pulse_intent">true</bool>\
    <bool name="config_displayBlanksAfterDoze">false</bool>' $MODPATH$device_features; then
                ui_print "  Error editing device features, skipping..."
                rm -r $features_path
            fi
        fi
        overlay_path=$MODPATH/system/product/overlay
	    mkdir -p $overlay_path
    	cp -f $MODPATH/files/AodOverlay.apk $overlay_path
    fi
    
	ui_print "- Adding additional files"
	wall_path="$MODPATH/system/product/media/wallpaper/sysui_editor_wallpaper_group/01_magazine"
	mkdir -p $wall_path
	cp -f "$MODPATH/files/magazine_08_mask.jpg" $wall_path
}

cleanup() {
	ui_print "  Installation files..."
    rm -rf "$MODPATH/files" 2>/dev/null
	ui_print "  Package cache..."
	find /data/system/package_cache -type f -iname *aod* -exec rm {} \;
	find /data/dalvik-cache -type f -iname *aod* -exec rm {} \;
}

run_install() {
    mods_center
    support_verification
    unzip -o "$ZIPFILE" -x 'META-INF/*' -d "$MODPATH" >&2
    install_files
    ui_print "- Setting permissions"
    set_perm_recursive $MODPATH 0 0 0755 0644
    ui_print "- Cleaning up"
    cleanup
	ui_print "- Reboot your device and enjoy "
}

run_install