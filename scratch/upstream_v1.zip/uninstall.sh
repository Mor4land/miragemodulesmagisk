#!/system/bin/sh
	find /data/system/package_cache -type f -iname *aod* -exec rm {} \;
	find /data/dalvik-cache -type f -iname *aod* -exec rm {} \;