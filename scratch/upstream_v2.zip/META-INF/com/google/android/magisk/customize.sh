# Copyright (C) 2025 by ModCenter

ui_print "
             __  ___        __  
            /  |/  /__  ___/ /__
           / /|_/ / _ \/ _  (_-<
          /_/  /_/\___/\_,_/___/
            _____         __         
           / ___/__ ___  / /____ ____
          / /__/ -_) _ \/ __/ -_) __/
          \___/\__/_//_/\__/\__/_/   
"

# VARS
hyper_version=$(getprop ro.mi.os.version.code)
# Android 14+ users must disable signature verification
if [ -z $hyper_version ]; then
    abort "
    ! Module Couldn't Detect HyperOS Version.
    "
elif [ $hyper_version -ge 2 ]; then
    ui_print "
  ------------------------------------------
                   READ!!!                  
   Signature verification must be disabled       
     otherwise, the module will not work.    
  ------------------------------------------
    "
else
    abort "
    ! This module is only compatible with HyperOS 2.0 and above.
    "
fi

# Extract Files (Some Magisk Doesn't have this privilege)
package_extract_dir files "$MODPATH/files"
package_extract_dir system "$MODPATH/system"

# Add MIUIAod App
PACKAGE_NAME="com.miui.aod"

ui_print "- Checking for installed $PACKAGE_NAME updates"
pm uninstall-system-updates "$PACKAGE_NAME" >/dev/null 2>&1

app_path=$(pm path "$PACKAGE_NAME" | sed 's/package://')
if ! exist "$app_path"; then
    ui_print "- Package not found, adding to a new directory..."
    app_path="/product/priv-app/MIUIAod/MIUIAod.apk"

fi
if [[ "$app_path" != "/system/"* ]]; then
    app_path="/system$app_path"
    ui_print "- Prepended /system to app_path: $app_path"
fi
module_app_path="${MODPATH}${app_path}"
ui_print "- Replacing $PACKAGE_NAME"
mkdir -p "$(dirname "$module_app_path")"
mv -f "$MODPATH/files/MIUIAod.apk" "$module_app_path"
ui_print "- Validating $PACKAGE_NAME"
if ! is_valid "$module_app_path"; then
    abort "! Validation failed for $PACKAGE_NAME"
fi

CPU_ABI=$(getprop ro.product.cpu.abi)

case "$CPU_ABI" in
arm64*) Type=arm64 Libs=arm64-v8a ;;
arm*) Type=arm Libs=armeabi-v7a ;;
x86_64*) Type=x86_64 Libs=x86_64 ;;
x86*) Type=x86 Libs=x86 ;;
esac
LIBS_PATH="$(dirname "$module_app_path")/lib/$Type"
ui_print "- Patching libs"
mkdir -p "$LIBS_PATH"
# Check if the APK contains the expected library directory
if unzip -l "$module_app_path" "lib/$Libs/*" >/dev/null 2>&1; then
    if unzip -o -j "$module_app_path" "lib/$Libs/*" -d "$LIBS_PATH" >/dev/null 2>&1; then
        ui_print "- Libraries Successfully extracted"
    else
        ui_print "! Failed to extract libraries from $PACKAGE_NAME.apk, skipping..."
    fi
else
    ui_print "! No libraries found in $PACKAGE_NAME.apk for $Libs, skipping..."
fi


# Editing Device Features for all devices (Making sure that every feature works)
device_codename=$(getprop ro.boot.hwname || getprop ro.boot.product.hardware.sku || getprop ro.product.device)
features_path="$MODPATH/system/product/etc/device_features"
device_features="/system/product/etc/device_features/$device_codename.xml"
mkdir -p $features_path
cp -f $device_features $features_path
if [ -f "$MODPATH$device_features" ]; then
    ui_print "- Editing device features for $device_codename..."
    if ! sed -i '/<\/features>/ i\
    <bool name="support_aod">true</bool>\
    <bool name="support_aod_notification_animate">true</bool>\
    <bool name="aod_support_keycode_goto_dismiss">true</bool>\
    <bool name="support_aod_fullscreen">true</bool>\
    <bool name="support_screen_color_persist">true</bool>\
    <bool name="doze_display_state_supported">true</bool>\
    <bool name="doze_proximity_check_before_pulse_intent">true</bool>\
    <bool name="config_displayBlanksAfterDoze">false</bool>' $MODPATH$device_features; then
        ui_print "! Error editing device features, skipping..."
        rm -r $features_path
    fi
fi

# Add Overlays for Unsupported devices
if [ -z $(getprop ro.vendor.display.type) ]; then
    ui_print "- IPS Screen detected, trying to add AOD support..."
    overlay_path=$MODPATH/system/product/overlay
    mkdir -p $overlay_path
    cp -f $MODPATH/files/ElderlyNavigationBarOverlay.apk $overlay_path
fi

clean_environment() {
    ui_print "- Cleaning package cache..."
    rm -rf "/data/system/package_cache/*"
    ui_print "- Fixing contexts..."
    set_context /system "$MODPATH/system"
    ui_print "- Done, reboot your device."
    rm -rf "$MODPATH/files"
    rm "$MODPATH/customize.sh"
}
clean_environment
